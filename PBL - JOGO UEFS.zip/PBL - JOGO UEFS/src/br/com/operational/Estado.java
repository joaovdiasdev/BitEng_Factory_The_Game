package br.com.operational;

public class Estado {
	private boolean aberto;
	private boolean fechado;
	private boolean dentro;
	private boolean fora;
	
	public Estado() {
		aberto = 0;
		fechado = 0;
		dentro = 0;
		fora = 0;
	}
}
