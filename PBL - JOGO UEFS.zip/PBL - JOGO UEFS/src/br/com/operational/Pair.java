package br.com.operational;

public class Pair {
	protected double x;
	protected double y;

	public Pair() {
		x = 0.0;
		y = 0.0;
	}

}