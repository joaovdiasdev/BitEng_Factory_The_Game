package br.com.operational;

public class Level {
	private int xpInt;
	private int nivel;
	
	public Level() {
		xpInt = 0;
		nivel = 0;	}
	
	public void levelUp() {
		nivel ++;
	}
}
