package br.com.operational;

public class Grid {
	private Pair par = new Pair();
	
	public Grid() {
		par.x = 0.0;
		par.y = 0.0;
	}
	
	public void axisX() {
		par.x = par.x++;
	}
	public void axisY() {
		par.y = par.y++;
	}
	public void negAxisX() {
		par.x = par.x--;
	}
	public void negAxisY() {
		par.y = par.y--;
	}
}
