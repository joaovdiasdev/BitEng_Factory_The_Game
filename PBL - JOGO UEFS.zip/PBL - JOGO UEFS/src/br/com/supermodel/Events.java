package br.com.supermodel;

public class Events {

}
