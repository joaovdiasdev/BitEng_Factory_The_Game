package br.com.supermodel;

import java.util.List;

import br.com.submodels.*;

public class Features {
	private Color corCabeloString;
	private List<Clothes> listaClothes;
	private Hair tipoHair;
	
	public Features(Color corCabelo, List<Clothes> roupasLista, Hair cabelo) {
		corCabeloString = corCabelo;
		listaClothes = roupasLista;
		tipoHair = cabelo;
	}

	public Color getCorCabeloString() {
		return corCabeloString;
	}

	public void setCorCabeloString(Color corCabeloString) {
		this.corCabeloString = corCabeloString;
	}

	public List<Clothes> getListaClothes() {
		return listaClothes;
	}

	public void setListaClothes(List<Clothes> listaClothes) {
		this.listaClothes = listaClothes;
	}

	public Hair getTipoHair() {
		return tipoHair;
	}

	public void setTipoHair(Hair tipoHair) {
		this.tipoHair = tipoHair;
	}
	
}
