package br.com.supermodel;

import java.util.Arrays;
import java.util.List;

import br.com.operational.*;

public class Player {
	private String nomeString;
	private String idString;
	private Grid posicaoPair;
	private Features caracteristicasFeatures;
	private List<String> materiaStrings;
	private List<Game> jogosAtivosGames;
	private int idadeInt;
	private int xpInt;
	private int motivacaoInt;
	private int saudeInt;
	private double energiaDouble;
	private double dinheiroDouble;
	private double scoreDouble;
	
	public Player(String nome, int idade) {
		nomeString = nome;
		idadeInt = idade;
		energiaDouble = 100;
		posicaoPair = new Grid();
		xpInt = 0;
		motivacaoInt = 100;
		saudeInt = 100;
		dinheiroDouble = 400;
		scoreDouble = 0.0;
		materiaStrings = Arrays.asList("Algoritmos I", "TFH", "PBL", "Introdução a Eletrônica", "Pré-Cálculo", "Introdução a Ecomp", "PTTA");
	}
	
	public void andarFrente() {
		posicaoPair.axisX();
	}
	public void andarTras() {
		posicaoPair.negAxisX();
	}
	public void andarCima() {
		posicaoPair.axisY();
	}
	public void andarBaixo() {
		posicaoPair.negAxisY();
	}
	public void comer(Food comida) {
		
	}
}
