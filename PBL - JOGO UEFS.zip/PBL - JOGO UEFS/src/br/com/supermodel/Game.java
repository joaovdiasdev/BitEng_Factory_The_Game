package br.com.supermodel;

public class Game {

}
