package br.com.supermodel;

public class Food {
	private String nomeFoodString;
	private String categoriaFoodString;
	private double precoFood;
	private int saborEscala;
	
	public Food(String nomeString, String categoria, double preco, int escalaSabor) {
		nomeFoodString = nomeString;
		categoriaFoodString = categoria;
		precoFood = preco;
		saborEscala = escalaSabor;
	}
}
