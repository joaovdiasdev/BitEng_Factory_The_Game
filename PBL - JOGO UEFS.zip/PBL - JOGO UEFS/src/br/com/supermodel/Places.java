package br.com.supermodel;

import java.util.List;

import br.com.operational.Pair;

public class Places {
	private String nomeLocalString;
	private Pair posicaoLocalPair;
	private List<Events> listaEventosEvents;
}
