package br.com.supermodel;

public class Characters {

}
