package br.com.submodels;

public class Hair {

}
