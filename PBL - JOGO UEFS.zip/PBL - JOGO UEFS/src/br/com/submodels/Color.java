package br.com.submodels;

public class Color {

}
