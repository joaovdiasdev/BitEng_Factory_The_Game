package br.com.submodels;

import br.com.supermodel.Food;

public class JunkFood extends Food {
	private int motivacao
}
