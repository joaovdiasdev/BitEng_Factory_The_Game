package br.com.submodels;

public class Clothes {

}
