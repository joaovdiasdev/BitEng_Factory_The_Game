package br.com.submodels;

import br.com.supermodel.Food;

public class HealthFood extends Food{
	private int vitaminas;
	
	private HealthFood() {
		vitaminas = 1;
	}
}
