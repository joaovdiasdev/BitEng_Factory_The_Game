package br.com.submodels;

import br.com.supermodel.Events;

public class RequeiredEvents extends Events {
	
}
