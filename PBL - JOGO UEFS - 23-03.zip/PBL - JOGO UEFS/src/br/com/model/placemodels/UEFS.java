package br.com.model.placemodels;

import java.util.List;

import br.com.model.supermodel.Places;

public class UEFS extends Places{
	private List<Modulo> listaModulos;
	private Places reitoriaPlaces;
	private Places bandejaoPlaces;
}
