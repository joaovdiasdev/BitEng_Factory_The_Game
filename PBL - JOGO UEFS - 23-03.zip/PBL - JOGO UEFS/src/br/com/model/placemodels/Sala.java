package br.com.model.placemodels;

public class Sala {

}
