package br.com.model.placemodels;

public class Modulo {

}
