package br.com.model.operational;

public class Grid {
	private Pair origem;
	private Pair posicaoPair;
	
	public class Pair {
		private double x;
		private double y;

		public Pair(double x, double y) {
			this.x = x;
			this.y = y;
		}

	}
	
	public Grid(double x, double y) {
		origem = new Grid.Pair(0.0, 0.0);
		posicaoPair = new Grid.Pair(x, y);
	}
	
	public void axisX() {
		posicaoPair.x = origem.x++;
	}
	public void axisY() {
		posicaoPair.y = origem.y++;
	}
	public void negAxisX() {
		posicaoPair.x = origem.x--;
	}
	public void negAxisY() {
		posicaoPair.y = origem.y--;
	}
	public Pair getPosicao() {
		return posicaoPair;
	}
}
