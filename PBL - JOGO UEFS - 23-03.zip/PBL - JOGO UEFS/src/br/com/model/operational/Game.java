package br.com.model.operational;

public class Game {

}
