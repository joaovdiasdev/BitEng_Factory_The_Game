package br.com.model.user;

import java.util.ArrayList;
import java.util.List;

import br.com.model.submodels.Clothes;
import br.com.model.supermodel.*;

public class Inventory {
	private Item[][] matriz;
	
	public Inventory() {
		matriz = new Item[3][8];
	}
	
	public void adicionar(Item item, int x, int y) {
		matriz[x][y] = item;
	}
	public void deletar(Item item, int x, int y) {
		if(matriz[x][y] != null) {
			matriz[x][y] = null;
		}
		else {
			;
		}
	}
	public Item[][] getInventory() {
		return matriz;
	}
	
	public void usarItem(Item[][] matriz, Object item, int x, int y) {
		matriz[x][y].getQuantidadeInt();
	}
	
}
