package br.com.model.user;

import java.util.ArrayList;
import java.util.List;

import br.com.model.submodels.*;

public class Features {
	private Color corCabeloString;
	private List<Clothes> listaClothes;
	private Hair tipoHair;
	
	public Features() {
		corCabeloString = new Color(); 
		listaClothes = new ArrayList<Clothes>();
		tipoHair = new Hair();
	}

	public Color getCorCabeloString() {
		return corCabeloString;
	}

	public void setCorCabeloString(Color corCabeloString) {
		this.corCabeloString = corCabeloString;
	}

	public List<Clothes> getListaClothes() {
		return listaClothes;
	}

	public void setListaClothes(List<Clothes> listaClothes) {
		this.listaClothes = listaClothes;
	}

	public Hair getTipoHair() {
		return tipoHair;
	}

	public void setTipoHair(Hair tipoHair) {
		this.tipoHair = tipoHair;
	}
	
}
