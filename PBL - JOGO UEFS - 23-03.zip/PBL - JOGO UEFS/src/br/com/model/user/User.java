package br.com.model.user;

public class User {

}
