package br.com.model.user;

import java.lang.classfile.Superclass;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.com.model.operational.*;
import br.com.model.submodels.*;
import br.com.model.supermodel.Characters;
import br.com.model.supermodel.Item;
import br.com.model.supermodel.Subjects;

public class Player extends Characters{
	private PlayerStats statusJogadorPlayerStats;
	private Features caracteristicasFeatures;
	private Inventory mochila;
	private List<Subjects> disciplinas;
	
	
	public Player(String nome, int idade) {
		super(nome, idade);
		statusJogadorPlayerStats = new PlayerStats();
		caracteristicasFeatures = new Features(null, null, null);
		disciplinas = new ArrayList<Subjects>();
		mochila = new Inventory();
	}
	
	public void comerSaudavel(Food comida) {
		statusJogadorPlayerStats.somaSaude(3);
		statusJogadorPlayerStats.somaEnergia(1);
		statusJogadorPlayerStats.somaMotivacao(1);
	}
	public void comerBesteira(Food comida) {
		statusJogadorPlayerStats.diffSaude(3);
		statusJogadorPlayerStats.somaEnergia(5);
		statusJogadorPlayerStats.somaMotivacao(5);
	}
	public void comprarItem(Item item) {
		statusJogadorPlayerStats.diffDinheiro(item.getPrecoDouble());
		item.setQuantidadeInt(item.getQuantidadeInt() + 1);
	}
	
	public void verMochila() {
		mochila.getInventory();
	}

	public PlayerStats getStatusJogadorPlayerStats() {
		return statusJogadorPlayerStats;
	}

	public Features getCaracteristicasFeatures() {
		return caracteristicasFeatures;
	}

	public Inventory getMochila() {
		return mochila;
	}

	public List<Subjects> getDisciplinas() {
		return disciplinas;
	}
	
}
