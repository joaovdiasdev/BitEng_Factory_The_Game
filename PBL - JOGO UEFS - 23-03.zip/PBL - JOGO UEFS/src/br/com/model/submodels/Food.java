package br.com.model.submodels;

import br.com.model.supermodel.Item;

public class Food extends Item{

	public Food(String nome, int quantidade, double preco) {
		super(nome, quantidade, preco);
		// TODO Auto-generated constructor stub
	}
	
}