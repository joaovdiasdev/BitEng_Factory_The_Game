package br.com.model.submodels;

public class Hair {

}
