package br.com.model.submodels;

public class Color {

}
