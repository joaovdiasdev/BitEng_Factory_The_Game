package br.com.model.submodels;

import br.com.model.supermodel.Events;

public class RequeiredEvents extends Events {
	
}
